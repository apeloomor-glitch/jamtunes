package com.jamtunes;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Talks to the free Jamendo API (https://developer.jamendo.com). */
public final class JamApi {
    public static final int PAGE_SIZE = 6;

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.ALWAYS)
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }

    public static CompletableFuture<List<Track>> search(String query, int page) {
        StringBuilder url = new StringBuilder("https://api.jamendo.com/v3.0/tracks/?format=json&audioformat=ogg");
        url.append("&client_id=").append(enc(Config.get().clientId));
        url.append("&limit=").append(PAGE_SIZE);
        url.append("&offset=").append(page * PAGE_SIZE);
        if (query == null || query.isBlank()) {
            url.append("&order=popularity_week");   // empty search = trending
        } else {
            url.append("&search=").append(enc(query.trim()));
        }
        HttpRequest req = HttpRequest.newBuilder(URI.create(url.toString()))
                .header("User-Agent", "JamTunes/1.0")
                .timeout(Duration.ofSeconds(15))
                .GET().build();
        return HTTP.sendAsync(req, HttpResponse.BodyHandlers.ofString()).thenApply(r -> parse(r.body()));
    }

    private static List<Track> parse(String body) {
        JsonObject root = JsonParser.parseString(body).getAsJsonObject();
        JsonObject headers = root.getAsJsonObject("headers");
        if (headers != null && headers.has("status") && !"success".equals(headers.get("status").getAsString())) {
            String msg = headers.has("error_message") ? headers.get("error_message").getAsString() : "Jamendo error";
            throw new RuntimeException(msg);
        }
        List<Track> out = new ArrayList<>();
        JsonArray arr = root.getAsJsonArray("results");
        if (arr == null) return out;
        for (JsonElement el : arr) {
            JsonObject o = el.getAsJsonObject();
            String audio = o.has("audio") && !o.get("audio").isJsonNull() ? o.get("audio").getAsString() : "";
            if (audio.isBlank()) continue;
            String name = o.has("name") ? o.get("name").getAsString() : "?";
            String artist = o.has("artist_name") ? o.get("artist_name").getAsString() : "?";
            int dur = o.has("duration") && !o.get("duration").isJsonNull() ? o.get("duration").getAsInt() : 0;
            out.add(new Track(name, artist, dur, audio));
        }
        return out;
    }

    public static byte[] download(String url) throws IOException, InterruptedException {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .header("User-Agent", "JamTunes/1.0")
                .timeout(Duration.ofSeconds(60))
                .GET().build();
        HttpResponse<byte[]> r = HTTP.send(req, HttpResponse.BodyHandlers.ofByteArray());
        if (r.statusCode() != 200) throw new IOException("HTTP " + r.statusCode());
        return r.body();
    }
}
