package com.jamtunes;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class JamScreen extends Screen {
    private static String lastQuery = "";
    private static List<Track> lastResults = List.of();
    private static int lastPage = 0;
    private static String message = "Type a song or artist and press Search (empty = trending).";

    private EditBox search;
    private EditBox keyBox;

    public JamScreen() {
        super(Component.literal("JamTunes"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        // One-time setup: Jamendo client ID
        if (Config.get().clientId.isBlank()) {
            keyBox = new EditBox(this.font, cx - 150, 70, 230, 20, Component.literal("Client ID"));
            keyBox.setMaxLength(64);
            keyBox.setHint(Component.literal("Paste your Jamendo client ID"));
            addRenderableWidget(keyBox);
            addRenderableWidget(Button.builder(Component.literal("Save"), b -> {
                String v = keyBox.getValue().trim();
                if (!v.isEmpty()) {
                    Config.get().clientId = v;
                    Config.save();
                    rebuildWidgets();
                }
            }).bounds(cx + 85, 70, 65, 20).build());
            return;
        }

        search = new EditBox(this.font, cx - 150, 28, 230, 20, Component.literal("Search"));
        search.setMaxLength(100);
        search.setHint(Component.literal("Search songs or artists..."));
        search.setValue(lastQuery);
        addRenderableWidget(search);
        setInitialFocus(search);

        addRenderableWidget(Button.builder(Component.literal("Search"), b -> doSearch(0))
                .bounds(cx + 85, 28, 65, 20).build());

        for (int i = 0; i < lastResults.size(); i++) {
            Track t = lastResults.get(i);
            addRenderableWidget(Button.builder(Component.literal(t.label()), b -> AudioPlayer.play(t))
                    .bounds(cx - 150, 56 + i * 20, 300, 18).build());
        }

        int y = this.height - 26;
        int[] w = {40, 62, 36, 36, 36, 40};
        int gap = 4;
        int total = gap * (w.length - 1);
        for (int v : w) total += v;
        int x = cx - total / 2;

        addRenderableWidget(Button.builder(Component.literal("< Prev"), b -> { if (lastPage > 0) doSearch(lastPage - 1); })
                .bounds(x, y, w[0], 20).build());
        x += w[0] + gap;
        addRenderableWidget(Button.builder(Component.literal("Pause/Play"), b -> AudioPlayer.togglePause())
                .bounds(x, y, w[1], 20).build());
        x += w[1] + gap;
        addRenderableWidget(Button.builder(Component.literal("Stop"), b -> AudioPlayer.stop())
                .bounds(x, y, w[2], 20).build());
        x += w[2] + gap;
        addRenderableWidget(Button.builder(Component.literal("Vol -"), b -> changeVolume(-0.1f))
                .bounds(x, y, w[3], 20).build());
        x += w[3] + gap;
        addRenderableWidget(Button.builder(Component.literal("Vol +"), b -> changeVolume(0.1f))
                .bounds(x, y, w[4], 20).build());
        x += w[4] + gap;
        addRenderableWidget(Button.builder(Component.literal("Next >"), b -> doSearch(lastPage + 1))
                .bounds(x, y, w[5], 20).build());
    }

    private void changeVolume(float d) {
        Config c = Config.get();
        c.volume = Math.max(0f, Math.min(1f, Math.round((c.volume + d) * 10f) / 10f));
        Config.save();
    }

    private void doSearch(int page) {
        lastQuery = search.getValue();
        lastPage = page;
        message = "Searching...";
        Minecraft mc = Minecraft.getInstance();
        JamApi.search(lastQuery, page).thenAccept(list -> mc.execute(() -> {
            lastResults = list;
            message = list.isEmpty() ? "No results." : "Pick a song to play.";
            if (mc.screen == this) rebuildWidgets();
        })).exceptionally(e -> {
            Throwable c = e.getCause() != null ? e.getCause() : e;
            mc.execute(() -> message = "Error: " + c.getMessage());
            return null;
        });
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        int cx = this.width / 2;
        g.centeredText(this.font, this.title, cx, 12, 0xFFFFFFFF);

        if (Config.get().clientId.isBlank()) {
            g.centeredText(this.font, Component.literal("One-time setup: free music needs a Jamendo client ID."), cx, 40, 0xFFFFFFFF);
            g.centeredText(this.font, Component.literal("Get one free at devportal.jamendo.com, then paste it below."), cx, 52, 0xFFAAAAAA);
            return;
        }

        String line;
        if (!AudioPlayer.status.isEmpty()) line = AudioPlayer.status;
        else if (AudioPlayer.current() != null)
            line = (AudioPlayer.isPaused() ? "Paused: " : "Now playing: ") + AudioPlayer.currentTitle();
        else line = message;
        g.centeredText(this.font, Component.literal(line), cx, this.height - 46, 0xFFFFFFFF);

        int vol = Math.round(Config.get().volume * 100);
        g.centeredText(this.font, Component.literal("Volume " + vol + "%   |   Page " + (lastPage + 1) + "   |   Music via Jamendo (CC licensed)"),
                cx, this.height - 36, 0xFFAAAAAA);
    }
}
