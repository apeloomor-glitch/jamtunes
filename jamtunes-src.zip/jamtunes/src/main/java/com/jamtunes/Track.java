package com.jamtunes;

public record Track(String name, String artist, int seconds, String url) {
    public String label() {
        String s = name + " - " + artist;
        if (s.length() > 46) s = s.substring(0, 45) + "...";
        return s + "  (" + (seconds / 60) + ":" + String.format("%02d", seconds % 60) + ")";
    }
    public String title() { return name + " - " + artist; }
}
