package com.jamtunes;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("jamtunes.json");
    private static Config inst = new Config();

    public String clientId = "";
    public float volume = 0.6f;

    public static Config get() { return inst; }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Config c = GSON.fromJson(Files.readString(FILE), Config.class);
                if (c != null) inst = c;
                if (inst.clientId == null) inst.clientId = "";
            } else {
                save();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(inst));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
