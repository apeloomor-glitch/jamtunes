package com.jamtunes;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.stb.STBVorbisInfo;
import org.lwjgl.system.MemoryUtil;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;

/**
 * Downloads an OGG stream, decodes it with LWJGL's bundled stb_vorbis
 * (no extra libraries needed) and plays it through Java Sound.
 */
public final class AudioPlayer {
    public static final class Session {
        final Track track;
        volatile boolean cancelled;
        volatile boolean paused;
        Session(Track t) { track = t; }
    }

    private static volatile Session active;
    public static volatile String status = "";

    public static synchronized void play(Track t) {
        stop();
        Session s = new Session(t);
        active = s;
        status = "Loading: " + t.title();
        Thread th = new Thread(() -> run(s), "JamTunes-Audio");
        th.setDaemon(true);
        th.start();
    }

    public static synchronized void stop() {
        Session s = active;
        if (s != null) s.cancelled = true;
        active = null;
        status = "";
    }

    public static void togglePause() {
        Session s = active;
        if (s != null) s.paused = !s.paused;
    }

    public static Session current() { return active; }
    public static boolean isPaused() { Session s = active; return s != null && s.paused; }
    public static String currentTitle() { Session s = active; return s == null ? "" : s.track.title(); }

    private static void run(Session s) {
        long vorbis = 0L;
        ByteBuffer data = null;
        IntBuffer err = null;
        ShortBuffer pcm = null;
        STBVorbisInfo info = null;
        SourceDataLine line = null;
        try {
            byte[] bytes = JamApi.download(s.track.url());
            if (s.cancelled) return;

            data = MemoryUtil.memAlloc(bytes.length);
            data.put(bytes).flip();
            err = MemoryUtil.memAllocInt(1);
            vorbis = STBVorbis.stb_vorbis_open_memory(data, err, null);
            if (vorbis == 0L) throw new IOException("Could not decode audio (code " + err.get(0) + ")");

            info = STBVorbisInfo.malloc();
            STBVorbis.stb_vorbis_get_info(vorbis, info);
            int channels = info.channels();
            int rate = info.sample_rate();

            AudioFormat fmt = new AudioFormat(rate, 16, channels, true, false);
            line = AudioSystem.getSourceDataLine(fmt);
            line.open(fmt, rate * channels); // ~0.5 s buffer
            line.start();

            Minecraft mc = Minecraft.getInstance();
            String title = s.track.title();
            mc.execute(() -> {
                if (mc.player != null) mc.player.displayClientMessage(Component.literal("\u266A Now playing: " + title), true);
            });
            if (!s.cancelled) status = "";

            int chunk = 4096;
            pcm = MemoryUtil.memAllocShort(chunk * channels);
            byte[] out = new byte[chunk * channels * 2];
            boolean lineStopped = false;

            while (!s.cancelled) {
                if (s.paused) {
                    if (!lineStopped) { line.stop(); lineStopped = true; }
                    Thread.sleep(50);
                    continue;
                } else if (lineStopped) {
                    line.start();
                    lineStopped = false;
                }
                pcm.clear();
                int n = STBVorbis.stb_vorbis_get_samples_short_interleaved(vorbis, channels, pcm);
                if (n <= 0) break;
                int total = n * channels;
                float vol = Config.get().volume;
                for (int i = 0; i < total; i++) {
                    int v = Math.round(pcm.get(i) * vol);
                    if (v > 32767) v = 32767; else if (v < -32768) v = -32768;
                    out[i * 2] = (byte) v;
                    out[i * 2 + 1] = (byte) (v >> 8);
                }
                line.write(out, 0, total * 2);
            }
            if (!s.cancelled) line.drain();
            if (active == s) { active = null; status = ""; }
        } catch (InterruptedException ignored) {
        } catch (Throwable e) {
            if (!s.cancelled) {
                status = "Error: " + e.getMessage();
                if (active == s) active = null;
            }
        } finally {
            if (line != null) { line.stop(); line.flush(); line.close(); }
            if (vorbis != 0L) STBVorbis.stb_vorbis_close(vorbis);
            if (info != null) info.free();
            if (pcm != null) MemoryUtil.memFree(pcm);
            if (err != null) MemoryUtil.memFree(err);
            if (data != null) MemoryUtil.memFree(data);
        }
    }
}
