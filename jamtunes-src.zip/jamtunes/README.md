# JamTunes (Fabric, Minecraft 26.2)
Press J in game -> search -> click a song -> it streams. Free (Jamendo, CC-licensed music), no Spotify, no Premium, no MP3 files.

1. Get a free client ID at https://devportal.jamendo.com (create an app).
2. Start the game, press J, paste the client ID once.
3. Needs Fabric Loader 0.19.1+, Fabric API, Java 25.

Build: push this folder to a GitHub repo -> Actions tab -> "build" -> download the jar artifact.
Or locally: install JDK 25 + Gradle 9.5+, run `gradle build`, jar is in build/libs/.
